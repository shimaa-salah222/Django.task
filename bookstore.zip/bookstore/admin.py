from django.contrib import admin

# Register your models here.
from bookstore.models import All_books
admin.site.register(All_books) 