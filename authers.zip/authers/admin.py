from django.contrib import admin

# Register your models here.

from authers.models import Auther
admin.site.register(Auther)