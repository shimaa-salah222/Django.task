from django.apps import AppConfig


class AuthersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'authers'
